package com.java;
interface TestPi{
	public int getsum(int x,int y);
}

public class Lamda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestPi pi =(x,y)->x+y;
		System.out.print("pi value is :"+pi.getsum(10, 20));

	}

}
