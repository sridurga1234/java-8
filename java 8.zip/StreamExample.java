package com.java;

import java.awt.List;
import java.util.ArrayList;

public class StreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
					ArrayList<String> names = new ArrayList<String>();
					names.add("sri");
					names.add("durga");
					names.add("Aditya");
					names.add("priya");
			long count = names.stream().filter(str->str.length()<6).count();
			System.out.println("there are " +count+" Strings with length less than 6");
			
					

	}

}
