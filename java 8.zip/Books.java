package com.java;

public class Books {
	private int isbn;
	private String bookname;
	public Books(int isbn, String bookname) {
		this.isbn = isbn;
		this.bookname = bookname;
	}
	public String getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public void setBookName(String string) {
		// TODO Auto-generated method stub
		
	}
	

}
